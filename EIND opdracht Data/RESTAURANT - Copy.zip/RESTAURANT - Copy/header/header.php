<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="header.css">
    <title>Document</title>
</head>
<body>
    
<header>
<div class="navbar">
   <H1>RESTAURANT</H1>
    <ul>
      <li><a href="../klant/insert_klant.php">KLANTEN</a></li>
      <li><a href="../Reservering/insert_reservering.php">RESERVERINGEN</a></li>
      <li><a href="../tafel/insert_tafel.php">TAFELS</a></li>
      <li><a href="../product/insert_product.php">PRODUCTEN</a></li>
      <li><a href="../factuur/add-factuur.php">Factuur</a></li>
    </ul>
  </div>

</header>

</body>
</html>