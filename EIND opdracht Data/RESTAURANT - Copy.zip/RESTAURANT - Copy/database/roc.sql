-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Apr 06, 2024 at 12:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roc`
--

-- --------------------------------------------------------

--
-- Table structure for table `factuur`
--

CREATE TABLE `factuur` (
  `Factuur_id` int(11) NOT NULL,
  `F_Datum` varchar(45) NOT NULL,
  `6%Btw` decimal(6,2) NOT NULL,
  `19%Btw` decimal(6,2) NOT NULL,
  `Totaal_excl_BTW` decimal(6,2) NOT NULL,
  `Totaal_incl_BTW` decimal(6,2) NOT NULL,
  `Prijs_totaal` decimal(6,2) NOT NULL,
  `Aantal_producten` int(11) NOT NULL,
  `Tafel_id` int(11) NOT NULL,
  `Product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `klant`
--

CREATE TABLE `klant` (
  `Klant_id` int(11) NOT NULL,
  `Klantnaam` varchar(45) NOT NULL,
  `Adres` varchar(45) NOT NULL,
  `Telefoonnummer` int(45) NOT NULL,
  `Leeftijd` int(11) NOT NULL,
  `Email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `klant`
--

INSERT INTO `klant` (`Klant_id`, `Klantnaam`, `Adres`, `Telefoonnummer`, `Leeftijd`, `Email`) VALUES
(1, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(2, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(3, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(4, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(5, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(6, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(7, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(8, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(9, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(10, 'ZEE', 'UIHFUIEFHEFH', 1417179877, 19, 'zee947100@gmail.com'),
(11, '', '', 0, 0, ''),
(12, '', '', 0, 0, ''),
(13, '', '', 0, 0, ''),
(14, '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_id` int(11) NOT NULL,
  `productnaam` varchar(255) NOT NULL,
  `omschrijving` varchar(45) NOT NULL,
  `Prijs_per_stuk` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_id`, `productnaam`, `omschrijving`, `Prijs_per_stuk`) VALUES
(1, 'TEA', 'zee', 728.00),
(2, 'TEA', 'zee', 728.00),
(3, 'TEA', 'zee', 728.00),
(4, 'trbbhtrh', 'rtv', 0.00),
(5, '', '', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `reservering`
--

CREATE TABLE `reservering` (
  `Reservering_id` int(11) NOT NULL,
  `Reservering_begin_tijd` time NOT NULL,
  `Reservering_eind_tijd` time NOT NULL,
  `Klant_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservering`
--

INSERT INTO `reservering` (`Reservering_id`, `Reservering_begin_tijd`, `Reservering_eind_tijd`, `Klant_id`) VALUES
(8, '00:01:23', '00:00:00', 1),
(9, '00:01:23', '00:00:00', 1),
(10, '00:01:23', '00:00:00', 1),
(11, '00:01:23', '00:00:00', 1),
(13, '00:01:23', '00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tafel`
--

CREATE TABLE `tafel` (
  `Tafel_id` int(11) NOT NULL,
  `Max_aantal_personen` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tafel`
--

INSERT INTO `tafel` (`Tafel_id`, `Max_aantal_personen`) VALUES
(1, '11'),
(2, '11'),
(3, ''),
(4, '11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `factuur`
--
ALTER TABLE `factuur`
  ADD PRIMARY KEY (`Factuur_id`),
  ADD KEY `fk1` (`Product_id`),
  ADD KEY `fk2` (`Tafel_id`);

--
-- Indexes for table `klant`
--
ALTER TABLE `klant`
  ADD PRIMARY KEY (`Klant_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_id`);

--
-- Indexes for table `reservering`
--
ALTER TABLE `reservering`
  ADD PRIMARY KEY (`Reservering_id`),
  ADD KEY `fk3` (`Klant_id`);

--
-- Indexes for table `tafel`
--
ALTER TABLE `tafel`
  ADD PRIMARY KEY (`Tafel_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `factuur`
--
ALTER TABLE `factuur`
  MODIFY `Factuur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `klant`
--
ALTER TABLE `klant`
  MODIFY `Klant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reservering`
--
ALTER TABLE `reservering`
  MODIFY `Reservering_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tafel`
--
ALTER TABLE `tafel`
  MODIFY `Tafel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `factuur`
--
ALTER TABLE `factuur`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`Product_id`) REFERENCES `product` (`Product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2` FOREIGN KEY (`Tafel_id`) REFERENCES `tafel` (`Tafel_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservering`
--
ALTER TABLE `reservering`
  ADD CONSTRAINT `fk3` FOREIGN KEY (`Klant_id`) REFERENCES `klant` (`Klant_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
