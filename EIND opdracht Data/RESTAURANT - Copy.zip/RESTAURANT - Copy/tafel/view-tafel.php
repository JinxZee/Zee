<?php
    include_once "tafel.php";
    include_once "../header/header.php";

    $dbtafel = new Tafel($myDb);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="tafel.css">
   <title>TAFELS</title>
</head>
<body>


<h2>VIEW TAFELS</h2>

<main>
   
<table class="table dark">
        <tr>
            <th>Tafel_id</th>
            <th>Max_aantal_personen</th>
            <th colspan="2">Action</th>
        </tr>

        <tr> <?php
            $tafels = $dbtafel->selectTafel(); 
            if ($tafels) { 
                foreach ($tafels as $tafel) {?>
            <td><?php echo $tafel['Tafel_id']?></td>
            <td><?php echo $tafel['Max_aantal_personen']?></td>
            <td><a href="edit-tafel.php?Tafel_id=<?php echo $tafel['Tafel_id']; ?>">Edit</a></td>
            <td><a href="delete-tafel.php?Tafel_id=<?php echo $tafel['Tafel_id']; ?>">Delete</a></td>
           <td></td>
        </tr> <?php } }?>
    </table>
   
  </main>




</body>
</html>
