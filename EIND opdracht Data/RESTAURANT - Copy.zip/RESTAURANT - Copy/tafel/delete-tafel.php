
<?php
include 'tafel.php';

try {
    $db = new DB(); 
    $tafel = new Tafel($db); 

    if(isset($_GET['Tafel_id'])) {
        $tafel->deleteTafel($_GET['Tafel_id']);
        header("Location:view-tafel.php");
        exit; 
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>