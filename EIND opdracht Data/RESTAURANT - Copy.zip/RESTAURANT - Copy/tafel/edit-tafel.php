<?php
include "tafel.php";
include "../header/header.php";

try {
    $db = new DB('roc');
    $tafel = new Tafel($db); 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $tafel->updateTafel($_POST["Max_aantal_personen"], $_GET['Tafel_id']);
        header("Location:view-tafel.php");
        exit; 
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="tafel.css">
   <title>TAFELS</title>
</head>
<body>


<h2>UPDATE TAFELS</h2>

<main>
    <form id="login_form" class="form_class" method="POST">


    
     
     <label for="Max_aantal_personen">MAX AANTAL PERSONEN</label>
     <input class="field_class" type="text" name="Max_aantal_personen">


     <button class="submit_class" type="submit" name="submit">Submit</button>
     <button class="submit_class" type="submit" name="submit"><a href="view-tafel.php">tafel bejkijken</a></button>

     <?php
      if (isset($message)) {
        foreach ($message as $message) {
          echo '<div class="message" style="text-align: center; font-size:30px; color: red;"  onclick="this.remove();">' . $message . '</div>';
        }
      }
      ?>
     
  
    </form>
  </main>








</body>
</html>