<?php
include '../database/db.php'; 

class Reservering {
    private $dbh;

    public function __construct(DB $dbh)
    {
        $this->dbh = $dbh;
    }

    public function insertReservering($Reservering_begin_tijd, $Reservering_eind_tijd, $Klant_id) {
        return $this->dbh->execute("INSERT INTO reservering (Reservering_begin_tijd, Reservering_eind_tijd, Klant_id) VALUES (?, ?, ?)", [$Reservering_begin_tijd, $Reservering_eind_tijd, $Klant_id]);
    }

    public function updateReservering($Reservering_begin_tijd, $Reservering_eind_tijd, $Klant_id, $Reservering_id) {
        $stmt = $this->dbh->execute("UPDATE reservering SET Reservering_begin_tijd = ?, Reservering_eind_tijd = ?, Klant_id = ? WHERE Reservering_id = ?");
        $stmt->execute([$Reservering_begin_tijd, $Reservering_eind_tijd, $Klant_id, $Reservering_id]);
    }

    public function deleteReservering(int $Reservering_id) {
        $stmt = $this->dbh->execute("DELETE FROM reservering WHERE Reservering_id = ?");
        $stmt->execute([$Reservering_id]);
    }

    public function selectReservering() : array {
        $stmt = $this->dbh->execute("SELECT * FROM reservering");
        $result = $stmt->fetchAll();
        return $result; 
    }
}
?>