<?php
include '../database/db.php'; 

try {
    $reservering = new Reservering($myDb);
    $reservering->deleteReservering($_GET['Reservering_id']);
    header("Location:view-Reservering.php");
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
