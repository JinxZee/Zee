<?php
    include_once "reservering.php";
    include "../header/header.php";

    $dbreservering = new Reservering($myDb);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        try{
            $dbreservering->insertReservering($_POST["Reservering_begin_tijd"], $_POST["Reservering_eind_tijd"], $_POST["Klant_id"]);
            ECHO "Success";
        } catch (Exception $e){
            echo "Error" . $e->getMessage();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="Reservering.css">
   <title>RESERVERINGEN</title>
</head>
<body>

<h2>RESERVERING TOEVOEGEN</h2>

<main>
    <form id="login_form" class="form_class" method="POST">
        <label for="Reservering_begin_tijd">BEGIN TIJD</label>
        <input class="field_class"type="text" name="Reservering_begin_tijd">
   
        <label for="Reservering_eind_tijd">EIND TIJD</label>
        <input class="field_class"type="text" name="Reservering_eind_tijd">


        <label for="Klant_id">KLANT ID</label>
        <input class="field_class"type="text" name="Klant_id" > 

 
        <button class="submit_class" type="submit" name="submit">Submit</button>
        <button class="submit_class" type="submit" name="submit"><a href="view-reservering.php">RESERVERING BEJKIJKEN</a></button>
        <?php
          if (isset($message)) {
            foreach ($message as $message) {
              echo '<div class="message" style="text-align: center; font-size:30px; color: red;"  onclick="this.remove();">' . $message . '</div>';
            }
          }
        ?>
    </form>
</main>
</body>
</html>






</body>
</html>
