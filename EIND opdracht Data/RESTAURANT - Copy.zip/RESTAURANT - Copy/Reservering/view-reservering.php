
<?php
    include "reservering.php";
    include "../header/header.php";   

    $dbreservering = new Reservering($myDb);
?>


<!DOCTYPE html>
            <html lang="en">
            <head>
               <meta charset="UTF-8">
               <meta name="viewport" content="width=device-width, initial-scale=1.0">
               <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
              <link rel="stylesheet" href="Reservering.css">
               <title>RESERVERINGEN</title>
            </head>
            <body>
            

<H2>VIEW RESERVERINGEN</H2>

            <table class="table dark">
        <tr>
            <th>Reservering_id</th>
            <th>Reservering_begin_tijd</th>
            <th>Reservering_eind_tijd</th>
            <th>Klant_id </th>
            <th colspan="2">Action</th>
        </tr>

        <tr> <?php
            $reserveringen = $dbreservering->selectReservering(); 
            if ($reserveringen) { 
                foreach ($reserveringen as $reservering) {?>
            <td><?php echo $reservering['Reservering_id']?></td>
            <td><?php echo $reservering['Reservering_begin_tijd']?></td>
            <td><?php echo $reservering['Reservering_eind_tijd']?></td>
            <td><?php echo $reservering['Klant_id']?></td>
            <td><a href="edit-reservering.php?Reservering_id=<?php echo $reservering['Reservering_id']; ?>">Edit</a></td>
            <td><a href="delete-reservering.php?Reservering_id=<?php echo $reservering['Reservering_id']; ?>">Delete</a></td>
           <td></td>
        </tr> <?php } }?>
    </table>
            </body>
            </html>
