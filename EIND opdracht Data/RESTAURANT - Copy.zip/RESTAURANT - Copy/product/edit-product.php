<?php
include "product.php";
include "../header/header.php";



try {
    $myDb = new DB('roc');
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $db->updateProduct($_POST["productnaam"], $_POST["omschrijving"], $_POST["Prijs_per_stuk"], $_GET['Product_id']);
        header("Location:view-product.php");
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Product.css">
    <title>Update Product</title>
</head>
<body>

<h2>UPDATE PRODUCT</h2>

<main>
    <form id="login_form" class="form_class" method="POST">
        <label for="productnaam">PRODUCT NAAM</label>
        <input class="field_class" type="text" name="productnaam">
        <label for="omschrijving">OMSCHRIJVING</label>
        <input class="field_class" type="text" name="omschrijving">
        <label for="Prijs_per_stuk">PRIJS</label>
        <input class="field_class" type="text" name="Prijs_per_stuk">
        <button class="submit_class" type="submit" name="submit">Submit</button>
        <button class="submit_class" type="submit" name="submit"><a href="select-product.php">Product bejkijken</a></button>
        <?php
       
     
     if (isset($message)) {
       foreach ($message as $message) {
         echo '<div class="message" style="text-align: center; font-size:30px; color: red;"  onclick="this.remove();">' . $message . '</div>';
       }
     }
     ?>
    
    </form>
</main>
</body>
</html>
