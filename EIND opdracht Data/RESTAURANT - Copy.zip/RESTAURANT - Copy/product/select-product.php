<?php
include "product.php";
include "../header/header.php";

$dbproduct = new Product($myDb);
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
   <link rel="stylesheet" href="Product.css">
   <title>Document</title>
</head>
<body>
<h2>VIEW PRODUCT</h2>


<table class="table dark">
        <tr>
            <th>Product Id</th>
            <th>Product  Naam</th>
            <th>Omschrijving</th> 
            <th>Prijs_per_stuk</th>
            <th colspan="2">Action</th>
        </tr>

        <?php
        $producten = $dbproduct->selectProduct(); 
        if ($producten) { 
            foreach ($producten as $product) {?>
                <tr>
                    <td><?php echo $product['Product_id']?></td>
                    <td><?php echo $product['productnaam']?></td>
                    <td><?php echo $product['omschrijving']?></td> 
                    <td><?php echo $product['Prijs_per_stuk']?></td>
                    <td><a href="edit-product.php?Product_id=<?php echo $product['Product_id']; ?>">Edit</a></td>
                    <td><a href="delete-product.php?Product_id=<?php echo $product['Product_id']; ?>">Delete</a></td>
                </tr>
        <?php }} ?>
    </table>





</body>
</html>








































