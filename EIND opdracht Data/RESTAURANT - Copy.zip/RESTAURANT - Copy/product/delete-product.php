<?php

include 'product.php';

try {
    $myDb = new DB('roc');
    $dbProduct = new Product($myDb);
    $dbProduct->deleteProduct($_GET['Product_id']);
    header("Location: view-product.php");
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

?>