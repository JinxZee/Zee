<?php
include "../database/db.php";

class Product {
    private $dbh;

    public function __construct(DB $dbh)
    {
        $this->dbh = $dbh;
    }

    public function insertProduct ($productnaam, $omschrijving, $Prijs_per_stuk){
        return $this->dbh->execute("INSERT INTO product (productnaam, omschrijving, Prijs_per_stuk) VALUES (?, ?, ?)", [$productnaam, $omschrijving, $Prijs_per_stuk]);
    }
    public function selectProduct() : array {
        $stmt = $this->dbh->execute("SELECT * FROM product");
      $result = $stmt->fetchAll();
      return $result; 
  }

    public function updateProduct($productnaam, $omschrijving, $Prijs_per_stuk, $Product_id) {
        $stmt = $this->dbh->execute("UPDATE product SET productnaam = ?, omschrijving = ?, Prijs_per_stuk = ? WHERE Product_id = ?");
        $stmt->execute([$productnaam, $omschrijving, $Prijs_per_stuk, $Product_id]);
    }

    public function deleteProduct(int $Product_id) {
        $stmt = $this->dbh->execute("DELETE FROM product WHERE Product_id = ?");
        $stmt->execute([$Product_id]);
    }
}
?>
