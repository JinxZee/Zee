<?php
include "factuur.php";
include "../header/header.php";

$message = ""; 

try {
    $db = new DB('roc');
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $db->updateFactuur($_POST['F_Datum'], $_POST['btw_6'], $_POST['btw_19'], $_POST['Totaal_excl_BTW'], $_POST['Totaal_incl_BTW'],
            $_POST['Prijs_totaal'], $_POST["aantal_producten"], $_POST["Tafel_id"], $_POST["Product_id"],
            $_GET['Factuur_id']);
        header("Location: view-factuur.php");
        exit; 
    }
} catch (Exception $e) {
    $message = "Error: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM"
          crossorigin="anonymous">
    <link rel="stylesheet" href="factuur.css">
    <title>TAFELS</title>
</head>
<body>

<h2>UPDATE FACTUUR</h2>

<main>
    <form id="login_form" class="form_class" method="POST" action="">

        <label for="F_Datum">F_Datum</label>
        <input class="field_class" type="text" name="F_Datum">

        <label for="btw_6">6% BTW</label>
        <input class="field_class" type="text" name="btw_6">

        <label for="btw_19">19% BTW</label>
        <input class="field_class" type="text" name="btw_19">

        <label for="Totaal_excl_BTW">Totaal_excl_BTW</label>
        <input class="field_class" type="text" name="Totaal_excl_BTW">

        <label for="Totaal_incl_BTW">Totaal_incl_BTW</label>
        <input class="field_class" type="text" name="Totaal_incl_BTW">

        <label for="Prijs_totaal">Prijs_totaal</label>
        <input class="field_class" type="text" name="Prijs_totaal">

        <label for="aantal_producten">aantal_producten</label>
        <input class="field_class" type="text" name="aantal_producten">

        <label for="Tafel_id">Tafel_id</label>
        <input class="field_class" type="text" name="Tafel_id">

        <label for="Product_id">Product_id</label>
        <input class="field_class" type="text" name="Product_id">

        <button class="submit_class" type="submit" name="submit">Submit</button>
    </form>

    <?php
    if (!empty($message)) {
        echo '<div class="message" style="text-align: center; font-size:30px; color: red;" onclick="this.remove();">' . $message . '</div>';
    }
    ?>

</main>

<button class="submit_class"><a href="view-factuur.php">factuur bejkijken</a></button>

</body>
</html>





</body>
</html>

