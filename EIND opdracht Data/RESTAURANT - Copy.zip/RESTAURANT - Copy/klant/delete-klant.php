

<?php

include 'klant.php';


try {
    $myDb = new DB('roc');
    $dbklant = new Klant($myDb);
    $dbklant->deleteKlant($_GET['Klant_id']);
    header("Location:view-klant.php");
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

?>