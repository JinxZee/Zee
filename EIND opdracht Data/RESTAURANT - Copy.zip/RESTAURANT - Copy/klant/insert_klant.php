
<?php

include 'klant.php';
include "../header/header.php";

$klant = new Klant($myDb);

if ($_SERVER['REQUEST_METHOD'] =="POST") { 
try {

           
    
           $klant->insertKlant($_POST['Klantnaam'],$_POST['Adres'],$_POST['Telefoonummer'],$_POST['Leeftijd'],$_POST['Email'] );
           $message[] = 'Verzonden :)';

           } catch (Exception $e) {
          echo 'Error: ' . $e->getMessage();
           }
           }

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="klant.css">
   <title>Document</title>
</head>
<body>



<h2>KLANTEN TOEVOEGEN</h2>

<main>


    <form id="login_form" class="form_class" method="POST">


     
     <label for="Klantnaam">KLANTNAAM</label>
     <input class="field_class" type="text" name="Klantnaam">

     <label for="Adres">ADRES</label>
     <input class="field_class" type="text" name="Adres">

     <label for="Telefoonnummer">TELEFOONNUMMER</label>
     <input class="field_class" type="text" name="Telefoonummer">

     <label for="Leeftijd">LEEFTIJD</label>
     <input class="field_class" type="text" name="Leeftijd">

     <label for="Email">EMAIL</label>
     <input class="field_class" type="email" name="Email" >

     <button class="submit_class" type="submit" name="submit">Submit</button>
     <button class="submit_class" name="submit"><a href="selectklant.php">Bekijk Klanten</a></button>

     <?php
      if (isset($message)) {
        foreach ($message as $message) {
          echo '<div class="message" style="text-align: center; font-size:30px; color: red;"  onclick="this.remove();">' . $message . '</div>';
        }
      }
      ?>
     
  
    </form>
  </main>

 
</body>
</html>





