<?php

include 'connectie.php';



if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST['merk']) || empty($_POST['model']) || empty($_POST['opslag']) || empty($_POST['prijs'])){
        echo "Vul alstublieft alle velden in";
    } 
    
  else {
 
    $sql = "INSERT INTO phones (phones_id, merk, model, opslag, prijs) VALUES (NULL, :merk, :model, :opslag, :prijs)";
    $stmt= $pdo->prepare($sql);


    $data = [
         "merk" => $_POST['merk'],
         "model" => $_POST['model'],
         "opslag" => $_POST['opslag'],
         "prijs" => $_POST['prijs'],

    ];

$stmt->execute($data);

  }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>POST</title>
   <link rel="stylesheet" href="style.css">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    
<h1>BEDRIJF X</h1>

<table class="table table-dark table-striped">
  <tr>
    <th>ID</th>
    <th>Merk</th>
    <th>Model</th>
    <th>Opslag</th>
    <th>Prijs</th>
    <th>Action</th>
  </tr> <?php
  $stmt = $pdo->query("SELECT * FROM phones");
$result = $stmt->fetchAll();
foreach ($result as $row) {
    echo "<td>" . $row['phones_id'] . "</td>";
    echo "<td>" . $row['merk'] . "</td>";
    echo "<td>" . $row['model'] . "</td>";
    echo "<td>" . $row['opslag'] . "</td>";
    echo "<td>" . $row['prijs'] . "</td>";
    echo "<td> <a href='update1.php?phones_id=".$row['phones_id'] . "'>Edit</a></td>";
?>
  <tr>
  <?php  }
  
  ?>
  </tr>

</table>

<div class="conntainer">
<form method="POST">

<label for="merk">Merk</label>
<input type="text" name="merk" >

<label for="model">Model</label>
<input type="text" name="model" >

<label for="opslag">Opslag</label>
<input type="number" name="opslag" >

<label for="prijs">Prijs</label>
<input type="number" name="prijs">

<input type="submit" name="submit" value="Submit">

</form>
</div>




</body>
</html>
