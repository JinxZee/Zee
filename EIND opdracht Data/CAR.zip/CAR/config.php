<?php

$conn = mysqli_connect('localhost:3307','root','','winkel') or die('connection failed');

?>