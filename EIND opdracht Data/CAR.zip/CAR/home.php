<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = 'localhost:3307';
    $db   = 'winkel';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';
    
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try 
    {
         $pdo = new PDO($dsn, $user, $pass, $options);
    
    } 
    catch (\PDOException $e) 
    {
         throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }}
  ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylezee.css">
    <link rel="stylesheet" href="styleindex.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
<div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">
<h2> RENT A CAR</h2>
        <ul>
            <li><a href="home.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="inloggen.php">INLOGGEN</a></li>
        </ul>







  <main>
  




      <section class="section featured-car" id="featured-car">
        <div class="container">

          <div class="title-wrapper">
         

            <a href="#" class="featured-car-link">
              <span>View more</span>

              <ion-icon name="arrow-forward-outline"></ion-icon>
            </a>
          </div>

          <ul class="featured-car-list">

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-1.jpg" alt="Toyota RAV4 2021" loading="lazy" width="440" height="300"
                    class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">Toyota RAV4</a>
                    </h3>

                    <data class="year" value="2021">2021</data>
                  </div>

                  

                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$440</strong> / month
                    </p>

                  
                    <button class="btn"><a href="inloggen.php">rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-2.jpg" alt="BMW 3 Series 2019" loading="lazy" width="440" height="300"
                    class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">BMW 3 Series</a>
                    </h3>

                    <data class="year" value="2019">2019</data>
                  </div>

                  

                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$350</strong> / month
                    </p>


                    <button class="btn"><a href="inloggen.php">Rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-3.jpg" alt="Volkswagen T-Cross 2020" loading="lazy" width="440"
                    height="300" class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">Volkswagen T-Cross</a>
                    </h3>

                    <data class="year" value="2020">2020</data>
                  </div>

                  

                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$400</strong> / month
                    </p>


                    <button class="btn"><a href="inloggen.php">rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-4.jpg" alt="Cadillac Escalade 2020" loading="lazy" width="440"
                    height="300" class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">Cadillac Escalade</a>
                    </h3>

                    <data class="year" value="2020">2020</data>
                  </div>

             

                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$620</strong> / month
                    </p>


                    <button class="btn"><a href="inloggen.php">rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-5.jpg" alt="BMW 4 Series GTI 2021" loading="lazy" width="440"
                    height="300" class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">BMW 4 Series GTI</a>
                    </h3>

                    <data class="year" value="2021">2021</data>
                  </div>

                 

                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$530</strong> / month
                    </p>


                    <button class="btn"><a href="inloggen.php">rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

            <li>
              <div class="featured-car-card">

                <figure class="card-banner">
                  <img src="images/car-6.jpg" alt="BMW 4 Series 2019" loading="lazy" width="440" height="300"
                    class="w-100">
                </figure>

                <div class="card-content">

                  <div class="card-title-wrapper">
                    <h3 class="h3 card-title">
                      <a href="#">BMW 4 Series</a>
                    </h3>

                    <data class="year" value="2019">2019</data>
                  </div>

              
                 
                  <div class="card-price-wrapper">

                    <p class="card-price">
                      <strong>$490</strong> / month
                    </p>


                    <button class="btn"><a href="inloggen.php">rent now</a></button>

                  </div>

                </div>

              </div>
            </li>

          </ul>

        </div>
      </section>






</div>
</html>