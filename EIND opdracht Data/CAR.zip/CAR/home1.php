<?php
$host = 'localhost:3307';
$db   = 'winkel';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:inloggen.php');
}

if (isset($_GET['logout'])) {
    unset($user_id);
    session_destroy();
    header('location:inloggen.php');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stmt = $pdo->prepare($sql);

    $data = [
        "car_id" => $_POST['car_id'],
        "car_name" => $_POST['car_name'],
        "car_image" => $_POST['car_image'],
        "ac_price" => $_POST['ac_price'],
        "non_ac_price" => $_POST['merk'],
        "ac_price_per_day" => $_POST['ac_price_per_day'],
        "non_ac_price_per_day" => $_POST['non_ac_price_per_day'],
        "car_availability" => $_POST['car_availability']
    ];

    $stmt->execute($data);

  }



if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['brand'])) {
    $brand = $_GET['brand'];
    $car_id = $_GET['car_id'];

  
    $stmt = $pdo->prepare("SELECT * FROM cars WHERE car_name LIKE :brand AND car_id = :car_id");
    $stmt->execute(['brand' => "%$brand%", 'car_id' => $car_id]);
} else {
   
    $stmt = $pdo->query("SELECT * FROM cars");
}

$result = $stmt->fetchAll();


foreach ($result as $row) {

}





  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylezee.css">
    <link rel="stylesheet" href="styleindex.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
<div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">
<h2> RENT A CAR</h2>
        <ul>
            <li><a href="home.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="inloggen.php">INLOGGEN</a></li>
        </ul>

        <div class="container">

<div class="user-profile">

   <?php
      $select_user = mysqli_query($conn, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_user) > 0){
         $fetch_user = mysqli_fetch_assoc($select_user);
      };
   ?>

   <p> username : <span><?php echo $fetch_user['username']; ?></span> </p>
   <p> email : <span><?php echo $fetch_user['email']; ?></span> </p>
   <div class="flex">
      <a href="inloggen.php" class="btn">login</a>
      <a href="signup.php" class="option-btn">register</a>
      <a href="home1.php?logout=<?php echo $user_id; ?>" onclick="return confirm('are your sure you want to logout?');" class="delete-btn">logout</a>
   </div>

</div>

<div class="search-form">
    <form method="GET" action="home.php">
        <label for="search_brand">Search by Brand:</label>
        <input type="text" id="search_brand" name="search_brand">

        <label for="search_car_id">Search by Car ID:</label>
        <input type="text" id="search_car_id" name="search_car_id">

        <button type="submit">Search</button>
    </form>
</div>





      <table class="table table-dark table-striped">
  <tr>
    <th>car_id</th>
    <th>Brand</th>
    <th>Ac Price</th>
    <th>Non Ac Price</th>  
    <th>AC price per day</th>
    <th>Non Ac price per day</th>
    <th>Availabi</th>

  </tr> <?php

  $stmt = $pdo->query ("SELECT * FROM cars");

$result = $stmt->fetchAll();
foreach ($result as $row) {
    echo "<td>" . $row['car_id'] . "</td>";
    echo "<td>" . $row['car_name'] . "</td>";
    echo "<td>" . $row['ac_price'] . "</td>";
    echo "<td>" . $row['non_ac_price'] . "</td>";
    echo "<td>" . $row['ac_price_per_day'] . "</td>";
    echo "<td>" . $row['non_ac_price_per_day'] . "</td>";
    echo "<td>" . $row['car_availability'] . "</td>";
?>
  <tr>
  <?php  }
  
  ?>
  </tr>

</table>



</form>
</div>


























</div>
</html>