<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="klantservice.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">

            <ul>
                <li><a href="home.php">HOME</a></li>
                <li><a href="overons.php">OVER ONS</a></li>
                <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
                <li><a href="inloggen.php">INLOGGEN</a></li>
              </ul>
    </div>

<h1>Welkom bij onze Klantenservice</h1>
    </header>

    <section id="contact">
        <h2>Contacteer Ons</h2>
        <p>Heb je vragen of opmerkingen? Neem gerust contact met ons op.</p>
        <p>E-mail: <a href="mailto:klantenservice@example.com">klantenservice@example.com</a></p>
        <p>Telefoon: +31 123 456 789</p>
    </section>


</body>
</html>

</body>
</html>