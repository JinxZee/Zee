<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="overons.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">

        <ul>
            <li><a href="home.php">HOME</a></li>
            <li><a href="overons.php">OVER ONS</a></li>
            <li><a href="klantenservice.php">KLANTENSERVICE</a></li>
            <li><a href="inloggen.php">INLOGGEN</a></li>
        </ul>
    </div>


    <div class="content">
        <h1>Rent A Car</h1>
        <p>
        </p>

        
        <div>
        <button onclick="window.location.href = 'home.php'">Search cars</button>
        </div>

    </div>
    

</body>
</html>